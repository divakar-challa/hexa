# Upload Torture Test Pack

The fixtures behind the 12-step upload validation checklist: size extremes, filename traps, a spoofed content type, a file whose header is fine and body is not, archive path traversal, a decompression bomb, an SVG carrying a script, and a polyglot.

22 files, 2222 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Upload pipelines that check the extension and the client-supplied MIME type and nothing else. Run the whole pack through your endpoint: every file should be either accepted and stored safely, or rejected with a specific error. Anything accepted silently is a finding.

The largest file here is 1 MB, deliberately: this pack is meant to be cheap to fetch in CI on every
run. To exercise a real size cap, pull a specific size from https://hexaqa.com/size-ladder (up to
250 MB stored) or stream anything up to 2 GB from https://hexaqa.com/generator.

## Files

### size/0b.bin

- size: 0 bytes
- sha256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- what it is: Empty file, exactly 0 bytes.
- expected: Rejected: an empty file is not a valid upload.
- page: https://hexaqa.com/file/size-ladder/0b-bin

### size/1b.bin

- size: 1 bytes
- sha256: dabd3aff769f07eb2965401eb029974ebba3407afd02b26ddb564ea5f8efae72
- what it is: Exactly 1 bytes of deterministic incompressible pseudo-random data.
- expected: Accepted. Proves the zero-byte rejection is not an off-by-one.
- page: https://hexaqa.com/file/size-ladder/1b-bin

### size/1mb.bin

- size: 1048576 bytes
- sha256: 30b93b424b6eaae04620a6bafe1f7eb6b2aa62fb1455210bd5be45730fa777ff
- what it is: Exactly 1,048,576 bytes of deterministic incompressible pseudo-random data.
- expected: Accepted or rejected by your size cap, never buffered whole into memory.
- page: https://hexaqa.com/file/size-ladder/1mb-bin

### filename/spaces in name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Spaces in the filename.
- expected: Stored under a generated name; the original kept only as a label.
- page: https://hexaqa.com/file/filename-edge-cases/spaces-in-name-txt

### filename/report.pdf.exe

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Double extension where the real extension is last.
- expected: Rejected by the allow-list, matched on the real final extension.
- page: https://hexaqa.com/file/filename-edge-cases/report-pdf-exe

### filename/CON.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A Windows reserved device name.
- expected: Never written to disk as CON on Windows.
- page: https://hexaqa.com/file/filename-edge-cases/con-txt

### filename/trailing-dot.txt.

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A trailing dot after the extension.
- expected: Trailing dot stripped or the name rejected; Windows silently drops it.
- page: https://hexaqa.com/file/filename-edge-cases/trailing-dot-txt

### filename/invoice‮gnp.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Contains a right-to-left override (U+202E) so it renders as "invoicetxt.png".
- expected: The right-to-left override is stripped before the name is ever displayed.
- page: https://hexaqa.com/file/filename-edge-cases/invoice-gnp-txt

### filename/日本語ファイル名.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Japanese characters in the filename.
- expected: Round-trips unchanged, NFC-normalised.
- page: https://hexaqa.com/file/filename-edge-cases/txt

### filename/percent%20encoded.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A literal "%20" sequence in the filename.
- expected: Not double-decoded into a space.
- page: https://hexaqa.com/file/filename-edge-cases/percent-20encoded-txt

### image/fake-jpeg-is-executable.jpg

- size: 2131 bytes
- sha256: 4ba83fec93b79c99a1d2f2be5e10620d7ca634766d5a783a8d9a7a19c47d610f
- what it is: A file named .jpg whose magic bytes are the DOS/PE "MZ" signature. Contains no executable code - just the header and filler.
- expected: Rejected: the extension says JPEG, the bytes disagree.
- page: https://hexaqa.com/file/images/fake-jpeg-is-executable-jpg

### image/no-extension

- size: 183 bytes
- sha256: c84d8425542305e68c674701ed5a8db2f4e6fe0045d8543be22ca3ddc0a88f40
- what it is: A genuinely valid PNG with no file extension at all.
- expected: Identified as PNG from its signature, not from a missing extension.
- page: https://hexaqa.com/file/images/no-extension

### image/svg-with-script.svg

- size: 457 bytes
- sha256: cda5b1d93e5c72c74f1f3444232e2b52a927757aa6e240bcf724a0748408d623
- what it is: SVG containing an inline <script> block and an onload attribute. The payload only calls console.log and sets document.title - it is inert and does not exfiltrate anything.
- expected: Sanitised, rasterised, or served from a separate origin. Never inline.
- page: https://hexaqa.com/file/images/svg-with-script-svg

### security/polyglot-gif-html.gif

- size: 192 bytes
- sha256: c965bb91779eaa8bbf8a03cca8ea28223de282237a38b736541b8f14eb724b5f
- what it is: A file that is simultaneously a valid GIF (correct GIF89a header and dimensions) and valid HTML containing an inert script. Renders as an image to an image parser and as a page to a browser.
- expected: Served with nosniff so it can only ever be treated as an image.
- page: https://hexaqa.com/file/security-and-validation/polyglot-gif-html-gif

### office/corrupt-missing-content-types.docx

- size: 577 bytes
- sha256: 6de45712c47ec56fa5f14b701827e2ee7a6adf7296ec3e8a5657af63babe5b2a
- what it is: A DOCX-shaped ZIP that is missing its [Content_Types].xml part.
- expected: Rejected at parse time: a valid ZIP that is not a valid DOCX.
- page: https://hexaqa.com/file/office-documents/corrupt-missing-content-types-docx

### archive/zip-slip-traversal.zip

- size: 357 bytes
- sha256: bf5ee2334900a786100f6b030fa929e1a6101b1075f501ff8d7be41c0b38107e
- what it is: Archive containing an entry named ../../../../tmp/qa-zip-slip.txt. The payload is a harmless text marker, but the path escapes the extraction directory.
- expected: Entry refused. Nothing written outside the extraction directory.
- page: https://hexaqa.com/file/archives/zip-slip-traversal-zip

### archive/absolute-path.zip

- size: 161 bytes
- sha256: 9ea841f8c6258f058270bae465ccc538dc3d85d445dae479db0df4d2c6e6cba3
- what it is: Archive whose entry name is an absolute path (/tmp/qa-absolute.txt).
- expected: Entry refused.
- page: https://hexaqa.com/file/archives/absolute-path-zip

### archive/modest-zip-bomb.zip

- size: 1020252 bytes
- sha256: bdf118f346d0f790e0a707d49b0c15a3ca048463c69f3621949b821e87a1915a
- what it is: A ~1 MB archive that expands to roughly 1 GB: ten entries of 100 MB of zeroes each. Deliberately modest - this is not a 42 KB / 4.5 PB bomb.
- expected: Extraction aborted once the decompressed total passes your limit.
- page: https://hexaqa.com/file/archives/modest-zip-bomb-zip

### xml/billion-laughs.xml

- size: 794 bytes
- sha256: 9ca01fc0e877f248ff50f66de22330cbfb71785e34f26656cf68a0aac21f642c
- what it is: Classic entity-expansion bomb: nine levels of entities each referencing the previous ten times. Under 1 KB on disk, expands to ~1 GB of text if entity expansion is unbounded.
- expected: Rejected: entity expansion disabled.
- page: https://hexaqa.com/file/structured-data/billion-laughs-xml

### xml/xxe-file-disclosure.xml

- size: 141 bytes
- sha256: 3b24847c3f0f1c1e34b3d8b2bee9d2229da9613a35b7163bb4842ffcaf4aae83
- what it is: XML declaring an external entity that reads a local file. Targets /etc/hostname - deliberately innocuous rather than /etc/passwd.
- expected: Parsed with no file read attempted.
- page: https://hexaqa.com/file/structured-data/xxe-file-disclosure-xml

### json/deeply-nested-100000.json

- size: 200002 bytes
- sha256: 8d7bd09c0573c0c4d854b55795e2c3f1a781c2d4f2901de332a5cb8bab350e42
- what it is: A single value wrapped in 100,000 levels of nested arrays. Only ~200 KB on disk.
- expected: Rejected at a depth limit rather than overflowing the stack.
- page: https://hexaqa.com/file/structured-data/deeply-nested-100000-json

### csv/formula-injection.csv

- size: 357 bytes
- sha256: c591c3c65f09f7ce69b6b47558650baf9ad511d14df5c95e0fdd9977bcbf0d0f
- what it is: Cells beginning with =, +, -, @ and tab, which spreadsheet applications interpret as formulas. The payloads are non-destructive: they reference HYPERLINK and a harmless calculation.
- expected: Stored as text. Cells beginning = + - @ escaped on export.
- page: https://hexaqa.com/file/structured-data/formula-injection-csv

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
