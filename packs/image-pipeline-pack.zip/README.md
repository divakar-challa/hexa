# Image Pipeline Pack

PNG, JPEG, GIF, animated GIF, BMP, ICO, TIFF in both byte orders, lossless WEBP and SVG, plus a PNG with a deliberately wrong CRC, a truncated PNG, an 8000x8000 decompression risk, a spoofed JPEG and an SVG carrying a script.

17 files, 372 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Thumbnailers, converters and upload pipelines. The interesting failures are a decoder that allocates width times height before checking anything, a signature check that only reads four bytes, and treating SVG as an image rather than as executable XML.

## Files

### image/png-1x1.png

- size: 70 bytes
- sha256: 077158f9f77953e9b39eb582b999335adbd9af79e0ef9a76921243187682a937
- what it is: Single opaque pixel. The smallest valid PNG this corpus produces.
- expected: The smallest valid PNG. Accepted.
- page: https://hexaqa.com/file/images/png-1x1-png

### image/png-8000x8000.png

- size: 265089 bytes
- sha256: 0818a806b978790eab13e286e98c069a739648bda085a1b74fa24cc6963e4d58
- what it is: 8000x8000 PNG of flat colour. Compresses to a few hundred KB but expands to roughly 256 MB in memory.
- expected: Rejected by a dimension limit, or decoded without allocating w x h x 4 up front.
- page: https://hexaqa.com/file/images/png-8000x8000-png

### image/png-bad-crc.png

- size: 1309 bytes
- sha256: 10bcc5c930180c7276678fada6ab4bb9bb4768f559f2e942190fdb265e869c29
- what it is: Structurally complete PNG with a single corrupted byte inside the IDAT chunk CRC.
- expected: Rejected by a strict decoder; displayed by a lenient one. Know which you have.
- page: https://hexaqa.com/file/images/png-bad-crc-png

### image/png-truncated.png

- size: 719 bytes
- sha256: 5442ebef90a3212ce5fec1b88eb613bcf13ea075d7974af9bdd09700f3f45514
- what it is: Valid PNG header and partial IDAT, cut off before IEND.
- expected: Rejected. The signature and IHDR are intact.
- page: https://hexaqa.com/file/images/png-truncated-png

### image/no-extension

- size: 183 bytes
- sha256: c84d8425542305e68c674701ed5a8db2f4e6fe0045d8543be22ca3ddc0a88f40
- what it is: A genuinely valid PNG with no file extension at all.
- expected: Identified as PNG from its bytes.
- page: https://hexaqa.com/file/images/no-extension

### image/jpeg-baseline.jpg

- size: 2853 bytes
- sha256: cd87b4048afdb864fad74f0ff409c81c844d0043a00870bafeb5685dd061722d
- what it is: 256x256 baseline JPEG, 4:2:0 chroma subsampling, quality ~85, encoded from source.
- expected: Baseline JPEG. Accepted.
- page: https://hexaqa.com/file/images/jpeg-baseline-jpg

### image/fake-jpeg-is-executable.jpg

- size: 2131 bytes
- sha256: 4ba83fec93b79c99a1d2f2be5e10620d7ca634766d5a783a8d9a7a19c47d610f
- what it is: A file named .jpg whose magic bytes are the DOS/PE "MZ" signature. Contains no executable code - just the header and filler.
- expected: Rejected: the bytes are not a JPEG.
- page: https://hexaqa.com/file/images/fake-jpeg-is-executable-jpg

### image/gif-animated.gif

- size: 2409 bytes
- sha256: 1bbfaedc241b6979a270bc4aaf634406e775afcde1d65ab6ca440f3eab6cb545
- what it is: A looping animated GIF: four frames, 200 ms each, with a NETSCAPE2.0 loop block.
- expected: All four frames preserved, or deliberately flattened to the first.
- page: https://hexaqa.com/file/images/gif-animated-gif

### image/gif-static.gif

- size: 774 bytes
- sha256: 238bcf8798a3c67dcffbc88905cdf21f3b77dd2f0fcaec15924e654fd03f3480
- what it is: 128x128 static GIF with a 4-colour palette and real LZW compression.
- expected: The single-frame control.
- page: https://hexaqa.com/file/images/gif-static-gif

### image/bmp-24bit.bmp

- size: 49206 bytes
- sha256: 01e674d234756a13da06a462f27a7d2f39a2179dfe304695c7fb8387f2a3acae
- what it is: 128x128 uncompressed 24-bit BMP with bottom-up row order.
- expected: An uncompressed format with a bottom-up row order that catches naive readers.
- page: https://hexaqa.com/file/images/bmp-24bit-bmp

### image/favicon.ico

- size: 145 bytes
- sha256: 600217778af12052008c8d71781db93d7660a1021ebeb7ba87378ecc8a803d7f
- what it is: A 32x32 Windows ICO wrapping a PNG image (the modern ICO form).
- expected: A container holding more than one size.
- page: https://hexaqa.com/file/images/favicon-ico

### image/tiff-rgb-le.tif

- size: 27828 bytes
- sha256: ae49adf598e99a77c028f6fa7e64412e66a0608057a0f69094e3143ebd177720
- what it is: A baseline uncompressed 96x96 RGB TIFF in Intel (little-endian) byte order.
- expected: Little-endian TIFF, the common case.
- page: https://hexaqa.com/file/images/tiff-rgb-le-tif

### image/tiff-rgb-be.tif

- size: 27828 bytes
- sha256: 9a70f704da26587f4b667218071417b0c527aa9100b11776f27172f6f4fe2133
- what it is: The same image written in Motorola (big-endian) byte order, which begins "MM" instead of "II".
- expected: Big-endian TIFF. A reader assuming II misreads every offset in the file.
- page: https://hexaqa.com/file/images/tiff-rgb-be-tif

### image/flat-96x96.webp

- size: 32 bytes
- sha256: b106293152970ea05fe1349ba69fc45509e1e9bd4a5b2fa0d8b2e109ee79bcf1
- what it is: A 96x96 lossless WEBP (VP8L) in a single flat colour, 32 bytes in total.
- expected: Lossless WEBP. Note the file begins RIFF, like a WAV.
- page: https://hexaqa.com/file/images/flat-96x96-webp

### image/transparent-1x1.webp

- size: 32 bytes
- sha256: 643ed5e4ce28a95a6f079364243b6ce181b544d8b11f5a626d7831af3abb12b4
- what it is: A 1x1 semi-transparent lossless WEBP, the smallest useful WEBP fixture.
- expected: Half-opaque alpha, so flattening is visible immediately.
- page: https://hexaqa.com/file/images/transparent-1x1-webp

### image/svg-plain.svg

- size: 303 bytes
- sha256: 083bfde9c3ad9327b6d94c7337d66455717c543f2d765b3ad0a968188abcfcb0
- what it is: Clean SVG with shapes and text, no scripts or external references.
- expected: Harmless vector graphic. The control for the next one.
- page: https://hexaqa.com/file/images/svg-plain-svg

### image/svg-with-script.svg

- size: 457 bytes
- sha256: cda5b1d93e5c72c74f1f3444232e2b52a927757aa6e240bcf724a0748408d623
- what it is: SVG containing an inline <script> block and an onload attribute. The payload only calls console.log and sets document.title - it is inert and does not exfiltrate anything.
- expected: Never served inline from your own origin.
- page: https://hexaqa.com/file/images/svg-with-script-svg

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
