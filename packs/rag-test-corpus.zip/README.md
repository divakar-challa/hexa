# RAG Test Corpus

Nine documents about one invented company, in PDF, Word, Excel, HTML, email and Markdown. Each hides at least one fact behind a real extraction problem: columns drawn row by row, a sentence split by a page break, a footnote that overrides the body, a two-row spreadsheet header, text hidden by CSS, an answer that only survives in a quoted reply, a stale near-duplicate and Word splitting numbers across runs. Ships with a 15-question answer key in eval JSONL and a plain-text control.

11 files, 18 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

RAG ingestion: loaders, chunkers and retrievers. Most retrieval failures are extraction failures, where the text was never read correctly and the chunk holding the answer never existed. Run the answer key against the corpus, then against the control, and the gap between the two is what extraction is costing you.

How to use it:
1. Index files/rag/corpus/ and nothing else.
2. Ask every question in files/rag/answers.jsonl and grade against "expected" and "accept".
3. Build a second index from files/rag/baseline/all-facts.txt alone and run the same questions.
If the control scores well and the corpus does not, the model is fine and extraction is failing.
Where an answer matches "trap_answer", the pipeline fell for exactly the trap that file contains.
Never index answers.jsonl: it contains every answer.

## Files

### rag/answers.jsonl

- size: 4793 bytes
- sha256: 259e7220105d6fbace255dbe03a6e9c17b1ef010c11b3a78fa200c5d56138364
- what it is: The answer key: 15 questions in eval JSONL, each with the expected answer, accepted variants, source file, trap name, evidence, and the wrong answer the trap tends to produce.
- expected: Load it as an eval dataset. Never index it: it contains every answer.
- page: https://hexaqa.com/file/rag-test-corpus/answers-jsonl

### rag/baseline/all-facts.txt

- size: 1488 bytes
- sha256: c2df6752bd0dc9ec5022b19655969e86192d7412f3f6b745e9a04b75578edc52
- what it is: Every fact in the corpus as one plain sentence each, with its source file. The control.
- expected: Index this alone and run the answer key against it. If this scores well and rag/corpus/ does not, the model is fine and the extraction is what is failing.
- page: https://hexaqa.com/file/rag-test-corpus/all-facts-txt

### rag/corpus/firmware-3.1-notes-v1.md

- size: 491 bytes
- sha256: 1cfe9656befc9baf977d1f99b24f8ec434e6083b217c36b2ab40bf84c3a49d3b
- what it is: Superseded release notes, nearly identical to v2 but with the old default sample interval (10 seconds).
- expected: Near-duplicate retrieval: both versions score almost identically for the question, and only the front matter says which is current. Pair with firmware-3.1-notes-v2.md.
- page: https://hexaqa.com/file/rag-test-corpus/firmware-3-1-notes-v1-md

### rag/corpus/firmware-3.1-notes-v2.md

- size: 524 bytes
- sha256: 7d2d3e7ade70d33b3087a29505c5be24224abd510270677aaf99e5a8cc5578aa
- what it is: The current release notes: status current, supersedes v1, default sample interval 5 seconds.
- expected: The correct source for the sample interval. A pipeline that drops front matter cannot tell it from v1.
- page: https://hexaqa.com/file/rag-test-corpus/firmware-3-1-notes-v2-md

### rag/corpus/k2-specification.pdf

- size: 1575 bytes
- sha256: 72ff4ce10fda63fcd89f24b6552b3753781d08656f0f7d1edb9e9d89696ab9ea
- what it is: A specification sheet whose small-print footnote overrides the operating temperature in the body.
- expected: Retrieval returns the spec line (50 degrees C) without the footnote (40 degrees C for older serials), especially where small type or page furniture is filtered out.
- page: https://hexaqa.com/file/rag-test-corpus/k2-specification-pdf

### rag/corpus/price-list.xlsx

- size: 1854 bytes
- sha256: a731809af39849d2cf008dfc9fc55ce7b4b6871323ebc855b1785c6aad507919
- what it is: A price list with a two-row header: "Price (EUR)" merged over "Net" and "Gross incl. 19% VAT".
- expected: Loaders that take row 1 as the header (pandas read_excel default) name the gross column "Unnamed: 2" and read the sub-header row as data, so a question about the gross price often returns the net one.
- page: https://hexaqa.com/file/rag-test-corpus/price-list-xlsx

### rag/corpus/product-sheet-two-column.pdf

- size: 1654 bytes
- sha256: 118fa3e8a809640884399c1e2ea58943c4e4d28892270c112a7f435b2ea63947
- what it is: A two-column PDF whose columns are drawn row by row, so the content stream alternates between the columns.
- expected: Extraction that follows content stream order (pdftotext -raw, for one) interleaves the warranty and returns sentences line by line. Layout-aware extraction (pdftotext in its default mode) keeps them apart.
- page: https://hexaqa.com/file/rag-test-corpus/product-sheet-two-column-pdf

### rag/corpus/service-manual.docx

- size: 1199 bytes
- sha256: 8f195ed4250601a75a7cf7016fc94262a04bbaa942e26ea3ebb49c73421c6a60
- what it is: A Word document whose numbers and part codes are split across text runs, as Word does after editing.
- expected: Concatenating runs gives "every 12 months" and "QM-CAL-KIT". Any extractor that puts a space or newline between runs gives "every 1 2 months" and "QM- CAL- KIT".
- page: https://hexaqa.com/file/rag-test-corpus/service-manual-docx

### rag/corpus/staff-handbook.pdf

- size: 2697 bytes
- sha256: 34ba408fc3be89eef244b453d939b7da06c8f72ec4728ccab3e7fa865a2fc452
- what it is: A two-page PDF where the on-call allowance sentence starts on page 1 and its amount is on page 2.
- expected: Page-level chunking separates "an on-call allowance of" from "EUR 42 per weekend", with the page footer and next page header in between. Neither chunk answers the question on its own.
- page: https://hexaqa.com/file/rag-test-corpus/staff-handbook-pdf

### rag/corpus/support-faq.html

- size: 1111 bytes
- sha256: aa7900c6c7c07e4c6167da3a88bc2513eff0b91380fce6f91f9095abf216382f
- what it is: A support page carrying an old notice hidden by a CSS rule, contradicting the visible support hours.
- expected: Tag-stripping extraction (BeautifulSoup get_text, for one) keeps the hidden notice. Only an extractor that applies CSS, such as a browser's innerText, drops it.
- page: https://hexaqa.com/file/rag-test-corpus/support-faq-html

### rag/corpus/support-thread.eml

- size: 1061 bytes
- sha256: e2dad9e9b2604d82cd2277bf46bd08433da58cbcb7d2364c499b5a4e70ad302b
- what it is: A support reply whose only statement of the battery voltage is inside the quoted earlier message.
- expected: Quote stripping, used to de-duplicate email threads, removes the one line that answers the question and leaves "the voltage in my earlier reply is still correct".
- page: https://hexaqa.com/file/rag-test-corpus/support-thread-eml

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
