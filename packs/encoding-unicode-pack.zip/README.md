# Encoding & Unicode Pack

Text in UTF-8 with and without a BOM, UTF-16 in both byte orders, Latin-1, CRLF and LF line endings, zero-width and right-to-left characters, both Unicode normalization forms, a CSV whose BOM poisons the first column, an email with RFC 2047 encoded headers and an archive with non-ASCII entry names.

17 files, 5 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Importers, parsers and anything that stores user text. Run the pack through your ingest path and check that every file comes out as the same characters it went in as. The failures are silent by nature, so they have to be looked for deliberately.

## Files

### text/utf8-no-bom.txt

- size: 99 bytes
- sha256: 54838db0165f05296350688ed04e2304c616001ff8e1446a54ab24a10e8af99e
- what it is: UTF-8 without a byte-order mark. The correct modern default.
- expected: The baseline. Everything else is compared against this.
- page: https://hexaqa.com/file/documents/utf8-no-bom-txt

### text/utf8-with-bom.txt

- size: 102 bytes
- sha256: ac0d490b3c84d5f8e830a7860f3f9c96846a92021d9b124a97bef0cfd021391d
- what it is: UTF-8 with a leading BOM (EF BB BF).
- expected: BOM stripped before parsing, not treated as part of the first value.
- page: https://hexaqa.com/file/documents/utf8-with-bom-txt

### text/utf16le.txt

- size: 162 bytes
- sha256: 4496b6b074dfaf6b170cfce06dae05970fa0787985232918b702d85381fdf793
- what it is: UTF-16 little-endian with BOM, which is what Windows PowerShell and Notepad historically emit.
- expected: Detected as UTF-16 LE from the FF FE mark and decoded correctly.
- page: https://hexaqa.com/file/documents/utf16le-txt

### text/utf16be.txt

- size: 162 bytes
- sha256: f90d1333c7efc583acff83947170dba1e663066c672dd21ae0445edfcd3216d8
- what it is: UTF-16 big-endian with BOM.
- expected: Detected as UTF-16 BE from FE FF. Assuming little-endian reads garbage.
- page: https://hexaqa.com/file/documents/utf16be-txt

### text/latin1.txt

- size: 43 bytes
- sha256: f55e2be006165fb601823726e6bd0764b442a5dfbc348b7d3a797f4a97fc5d41
- what it is: ISO-8859-1 / Latin-1 encoded text with accented characters.
- expected: Decoded as Latin-1, not assumed to be UTF-8 and mangled.
- page: https://hexaqa.com/file/documents/latin1-txt

### text/zero-width-and-rtl.txt

- size: 94 bytes
- sha256: 655072c13266ced43394f7f4f66a7e59d5047ae53e2f17447b2a9bafe8a83e30
- what it is: Text containing zero-width spaces, zero-width joiners, and bidirectional override characters (U+202E).
- expected: Invisible characters detected and stripped or rejected, not stored.
- page: https://hexaqa.com/file/documents/zero-width-and-rtl-txt

### text/line-endings-crlf.txt

- size: 1071 bytes
- sha256: f1d13bf3e400ae9865148d88e8cbecbc553c5c78e76e833cf3b8e81d65280115
- what it is: 20 lines terminated with Windows CRLF (\r\n).
- expected: CRLF handled without leaving a stray carriage return on every value.
- page: https://hexaqa.com/file/documents/line-endings-crlf-txt

### text/line-endings-lf.txt

- size: 1051 bytes
- sha256: a6ef6400340b1a434b5d8eb8527e5ee71cf2eefff19135dab9f2b726c390df07
- what it is: 20 lines terminated with Unix LF (\n). Byte-for-byte content twin of the CRLF file.
- expected: The LF control for the CRLF case.
- page: https://hexaqa.com/file/documents/line-endings-lf-txt

### csv/bom-and-semicolons.csv

- size: 124 bytes
- sha256: f011c1f7fd1b20aa993782865d5884ca6aa23089fabe5dc560b47c041bdf080a
- what it is: UTF-8 BOM, semicolon delimiters and comma decimal separators - the format Excel produces in most European locales.
- expected: First column named id, not ﻿id. Delimiter sniffed, not assumed.
- page: https://hexaqa.com/file/structured-data/bom-and-semicolons-csv

### filename/nfc-café.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Precomposed Unicode (NFC): é is a single code point U+00E9.
- expected: Normalised to NFC on the way in.
- page: https://hexaqa.com/file/filename-edge-cases/nfc-caf-txt

### filename/nfd-café.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Decomposed Unicode (NFD): é is e + U+0301 combining acute.
- expected: Recognised as the same name as the NFC copy, not stored twice.
- page: https://hexaqa.com/file/filename-edge-cases/nfd-caf-txt

### filename/файл-кириллица.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Cyrillic characters in the filename.
- expected: Non-Latin filename round-trips unchanged.
- page: https://hexaqa.com/file/filename-edge-cases/txt

### filename/日本語ファイル名.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Japanese characters in the filename.
- expected: Same, in a script that needs three bytes per character in UTF-8.
- page: https://hexaqa.com/file/filename-edge-cases/txt

### filename/🦊-emoji-name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Emoji (4-byte UTF-8, outside the BMP) in the filename.
- expected: Astral-plane characters survive. Length checks count the right unit.
- page: https://hexaqa.com/file/filename-edge-cases/emoji-name-txt

### archive/unicode-entry-names.zip

- size: 563 bytes
- sha256: 905894694aafd53e946ca6328a8765cbf53f36ffc2c473f394ded37c9f0fad4f
- what it is: Entries named in Japanese, Arabic, Russian and emoji, with the UTF-8 flag (bit 11) set correctly.
- expected: Entry names decoded as UTF-8 via the flag bit, not the local code page.
- page: https://hexaqa.com/file/archives/unicode-entry-names-zip

### email/unicode-headers.eml

- size: 427 bytes
- sha256: b1fdce2f073aca773af37f6e5cfdac7e9c654199d488ed6ce264f0505a943ef7
- what it is: Subject and display name encoded as RFC 2047 encoded-words (=?UTF-8?B?...?=) carrying CJK, Arabic and emoji.
- expected: RFC 2047 encoded-word subject decoded rather than shown raw.
- page: https://hexaqa.com/file/email/unicode-headers-eml

### email/quoted-printable.eml

- size: 535 bytes
- sha256: 74a8ec24d3d75585cd8eb718b6fa01b4cd1e5493b20b53fd9c04b417bd15ce28
- what it is: A quoted-printable body with accented characters, soft line breaks and an = sign at a wrap boundary.
- expected: Quoted-printable body decoded, soft line breaks removed.
- page: https://hexaqa.com/file/email/quoted-printable-eml

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
