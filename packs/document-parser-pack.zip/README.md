# Document Parser Pack

Real documents in every common office format, including a legacy .xls that is an OLE2 compound file rather than a ZIP, plus the deliberately damaged ones: a PDF with a corrupt xref table, a truncated PDF, a DOCX missing its content-types part and an EPUB with a broken container.

15 files, 281 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Document converters, text extractors, preview generators and import pipelines. The valid files prove the happy path; the damaged ones prove your error handling exists, because every one of them passes an extension check and a signature check and only fails when something actually parses it.

## Files

### pdf/valid-1page.pdf

- size: 750 bytes
- sha256: 84e95ec0084af11ba5ddee05e2a6755a46124912b65e1378ff80bc1e119609ec
- what it is: Minimal well-formed single-page PDF 1.4 with selectable Helvetica text.
- expected: Opens. The minimal valid control.
- page: https://hexaqa.com/file/documents/valid-1page-pdf

### pdf/valid-500pages.pdf

- size: 264642 bytes
- sha256: a950f538dcb5480d277dd180a38ee00dfd827a6f1e2b1d34c72fd3ce0a618a25
- what it is: Well-formed PDF with 500 numbered pages.
- expected: Opens without loading every page into memory at once.
- page: https://hexaqa.com/file/documents/valid-500pages-pdf

### pdf/no-text-layer.pdf

- size: 1698 bytes
- sha256: b061ce1d9945d157fe3cd86249309776b9d438fbc55f16f5b56a041971d91224
- what it is: PDF whose only page draws vector rectangles and contains zero text operators.
- expected: Renders, but text extraction returns nothing. OCR fallback should trigger.
- page: https://hexaqa.com/file/documents/no-text-layer-pdf

### pdf/corrupt-xref.pdf

- size: 720 bytes
- sha256: bd5efc3d6ec6afa54aec7d16a763577239ce2e1fda8636bea12497b4d9046f32
- what it is: Valid PDF body with a deliberately wrong startxref offset, so the cross-reference table cannot be located.
- expected: Rejected at parse. The %PDF- header is perfectly valid.
- page: https://hexaqa.com/file/documents/corrupt-xref-pdf

### pdf/truncated.pdf

- size: 1394 bytes
- sha256: a0975aad80c61f7b47103d04c4143122aa1a48da51d0c7fe74772f3af3479d7b
- what it is: A valid PDF cut off at 60% of its length, simulating an interrupted upload.
- expected: Rejected. Header intact, body cut short.
- page: https://hexaqa.com/file/documents/truncated-pdf

### office/document.docx

- size: 1082 bytes
- sha256: 08deccf7b4eb6de82226463b72076dbefbc7fcc89b1c691ed5a83a5db349954c
- what it is: Word document (OOXML) with a heading and two paragraphs.
- expected: Opens in Word, LibreOffice and python-docx.
- page: https://hexaqa.com/file/office-documents/document-docx

### office/spreadsheet.xlsx

- size: 1726 bytes
- sha256: ad3641fda07651acf26ca9bbaea3d2ad56358ae560768524b2d4d3b5b3310dae
- what it is: Excel workbook with a header row, data rows, and a live SUM formula.
- expected: Opens, and the live formula is parsed.
- page: https://hexaqa.com/file/office-documents/spreadsheet-xlsx

### office/legacy-workbook.xls

- size: 3584 bytes
- sha256: e4ddabb0ba6f10493b909d5f3be09e70c94f622d6b97c9d12664c6527f33294e
- what it is: A real legacy Excel 97-2003 workbook: BIFF8 records inside an OLE2 compound file, with two sheets, numbers, and text held in a shared string table.
- expected: Opens. Note it is an OLE2 file, not a ZIP: nothing about .xlsx handling applies.
- page: https://hexaqa.com/file/office-documents/legacy-workbook-xls

### office/presentation.pptx

- size: 3790 bytes
- sha256: 918c7c135ed89f8b0f662d1ead1bfeb7c5b75a94f2e5e6ca4d4a4aa347a6c35f
- what it is: PowerPoint presentation with a slide master, layout and one titled slide.
- expected: Opens as a real OOXML presentation.
- page: https://hexaqa.com/file/office-documents/presentation-pptx

### office/macro-enabled.xlsm

- size: 1879 bytes
- sha256: f6ec219c93f337cc21e5cca02e3cd2a6928811c9a61e824b80c972306380c8b0
- what it is: Macro-enabled workbook structure with an inert VBA project placeholder (no executable code).
- expected: Blocked or allowed deliberately, not by accident.
- page: https://hexaqa.com/file/office-documents/macro-enabled-xlsm

### office/document.odt

- size: 853 bytes
- sha256: b59417f44b6996fd6c611bd8611b0a3c48f2e07f8b94cfb6fa55ee4a12bcaf18
- what it is: OpenDocument Text with the mandatory uncompressed "mimetype" entry stored first.
- expected: OpenDocument, with the mimetype entry stored first and uncompressed.
- page: https://hexaqa.com/file/office-documents/document-odt

### office/spreadsheet.ods

- size: 878 bytes
- sha256: 3ceb50ee098eec9e9d27179e972e375ed504bb9262c24b1ccb3b3c02038a0525
- what it is: OpenDocument Spreadsheet with a small table and the stored-first mimetype entry.
- expected: Same, with a table to import.
- page: https://hexaqa.com/file/office-documents/spreadsheet-ods

### office/corrupt-missing-content-types.docx

- size: 577 bytes
- sha256: 6de45712c47ec56fa5f14b701827e2ee7a6adf7296ec3e8a5657af63babe5b2a
- what it is: A DOCX-shaped ZIP that is missing its [Content_Types].xml part.
- expected: Rejected: a valid ZIP that is not a valid DOCX.
- page: https://hexaqa.com/file/office-documents/corrupt-missing-content-types-docx

### ebook/valid.epub

- size: 2148 bytes
- sha256: ad719e81f75520420d5d4688da7043e5acb7956cc26e7ca6b6523d48d647253d
- what it is: A valid EPUB 2 with metadata, an NCX table of contents and three chapters.
- expected: Opens in a reader.
- page: https://hexaqa.com/file/ebooks/valid-epub

### ebook/broken-container.epub

- size: 1516 bytes
- sha256: afd0525368dec495c11f8cff4db86c5d0e85b131f6888f1ba328502d12e3a59e
- what it is: EPUB whose META-INF/container.xml points at an OPF file that does not exist in the archive.
- expected: Rejected: its container.xml points at a package document (OEBPS/missing.opf) that is not in the archive.
- page: https://hexaqa.com/file/ebooks/broken-container-epub

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
