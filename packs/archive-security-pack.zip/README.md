# Archive & ZIP Security Pack

The archives an extractor has to survive: Zip Slip path traversal, an absolute-path entry, ten levels of nesting, a deliberately modest decompression bomb, non-ASCII entry names, a damaged central directory, plus clean TAR, GZIP and 7z controls.

13 files, 1004 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Extraction code. Most of it resolves entry paths against the destination without checking the result is still inside it, and trusts the uncompressed sizes written in the archive, both of which are attacker-controlled. Extract this pack into a disposable directory and check nothing escaped it.

## Files

### archive/valid-flat.zip

- size: 376 bytes
- sha256: a8e3fb09b187d71285f1b908f39f1734e43e8143d182505306af44b442852c32
- what it is: Three deflated text files at the archive root, no directories.
- expected: The control. Extracts cleanly.
- page: https://hexaqa.com/file/archives/valid-flat-zip

### archive/valid-nested-dirs.zip

- size: 390 bytes
- sha256: 45eb1c114ac57aae4c176790023d361faf483bf8dc266e0f4c31480f696dacd4
- what it is: Archive with entries five directory levels deep.
- expected: Directory structure recreated correctly.
- page: https://hexaqa.com/file/archives/valid-nested-dirs-zip

### archive/zip-slip-traversal.zip

- size: 357 bytes
- sha256: bf5ee2334900a786100f6b030fa929e1a6101b1075f501ff8d7be41c0b38107e
- what it is: Archive containing an entry named ../../../../tmp/qa-zip-slip.txt. The payload is a harmless text marker, but the path escapes the extraction directory.
- expected: Entry refused. Nothing written outside the target directory.
- page: https://hexaqa.com/file/archives/zip-slip-traversal-zip

### archive/absolute-path.zip

- size: 161 bytes
- sha256: 9ea841f8c6258f058270bae465ccc538dc3d85d445dae479db0df4d2c6e6cba3
- what it is: Archive whose entry name is an absolute path (/tmp/qa-absolute.txt).
- expected: Leading separator stripped or the entry refused outright.
- page: https://hexaqa.com/file/archives/absolute-path-zip

### archive/nested-10-deep.zip

- size: 1222 bytes
- sha256: 0a16d5d585e29772e170d57f939b3211f2ad5649ce876afc2a0d0d9d42752ab4
- what it is: A ZIP containing a ZIP containing a ZIP, ten levels down, with a text file at the centre.
- expected: Recursive extraction bounded by depth, if you recurse at all.
- page: https://hexaqa.com/file/archives/nested-10-deep-zip

### archive/modest-zip-bomb.zip

- size: 1020252 bytes
- sha256: bdf118f346d0f790e0a707d49b0c15a3ca048463c69f3621949b821e87a1915a
- what it is: A ~1 MB archive that expands to roughly 1 GB: ten entries of 100 MB of zeroes each. Deliberately modest - this is not a 42 KB / 4.5 PB bomb.
- expected: Aborted once the decompressed total passes your limit.
- page: https://hexaqa.com/file/archives/modest-zip-bomb-zip

### archive/unicode-entry-names.zip

- size: 563 bytes
- sha256: 905894694aafd53e946ca6328a8765cbf53f36ffc2c473f394ded37c9f0fad4f
- what it is: Entries named in Japanese, Arabic, Russian and emoji, with the UTF-8 flag (bit 11) set correctly.
- expected: Entry names decoded as UTF-8, not the system code page.
- page: https://hexaqa.com/file/archives/unicode-entry-names-zip

### archive/corrupt-central-directory.zip

- size: 219 bytes
- sha256: d1194edeac6e322b76436927038138a9dc8325a93fc5daed8e399df8b68ed7d5
- what it is: Valid local file headers, but the central directory signature is overwritten with garbage.
- expected: Rejected, or recovered by scanning local headers. Either is defensible; silently producing nothing is not.
- page: https://hexaqa.com/file/archives/corrupt-central-directory-zip

### archive/empty.zip

- size: 22 bytes
- sha256: 8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85
- what it is: A structurally valid ZIP containing zero entries (22-byte end-of-central-directory only).
- expected: Recognised as a valid archive containing no entries.
- page: https://hexaqa.com/file/archives/empty-zip

### archive/valid.tar

- size: 4096 bytes
- sha256: 10423077ca0e6bd4595013c517de17a831309c3c0fa9c79bb3c2f01d46e2ee7c
- what it is: A USTAR tar archive with three files, including one in a subdirectory.
- expected: Handled despite the ustar magic sitting 257 bytes in.
- page: https://hexaqa.com/file/archives/valid-tar

### archive/valid.tar.gz

- size: 188 bytes
- sha256: 0da101bf8694244200910ca6601eb14a9b7cd9cc543af255392559d3521d2548
- what it is: The gzip-compressed form of a tar archive - the ubiquitous .tar.gz.
- expected: Double extension handled without stopping at .gz.
- page: https://hexaqa.com/file/archives/valid-tar-gz

### archive/single-file.gz

- size: 146 bytes
- sha256: 60fbfdaaf05f0901d2ce5130ea4edc59e031cb30467a4c9c01abfd619f1d4182
- what it is: A single gzip-compressed text file (not a tar), with the original filename in the header.
- expected: Plain gzip stream, no tar inside.
- page: https://hexaqa.com/file/archives/single-file-gz

### archive/stored.7z

- size: 303 bytes
- sha256: 31e9a5822e78fcadae442eef9dabe5162560bcc37734aebabf43e0e08456273e
- what it is: A valid .7z archive holding three files, including one in a subdirectory. Entries use the Copy codec, so they are stored rather than compressed.
- expected: A format whose metadata sits after the payload, so a truncated copy loses the file list.
- page: https://hexaqa.com/file/archives/stored-7z

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
