# Email Parser Pack

All 19 email fixtures: RFC 5322 .eml as Gmail, Thunderbird and Outlook export it, a real Outlook .msg written as an OLE2 compound file, an Apple Mail .emlx, a Unix mbox and an MHTML web archive, covering folded headers, encoded words, quoted-printable, inline images, attachments and spoofed senders.

19 files, 18 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Mail importers, archivers, ticketing systems and migration tooling. Every address is on the reserved example.test domain and every person in them is invented, so nothing can be delivered anywhere and no real personal data is involved.

## Files

### email/apple-mail.emlx

- size: 742 bytes
- sha256: 8c2736971c4ea2eb42a5cc19cd383dc2845841ae9f04628b7db92f0f6775b865
- what it is: Apple Mail’s on-disk format: a byte-count line, then the RFC 822 message, then an XML plist of Mail’s own metadata.
- expected: Apple Mail import and migration. The leading byte count and trailing plist break every tool that assumes a .emlx is just an .eml, which is the usual reason Mail exports fail to import elsewhere.
- page: https://hexaqa.com/file/email/apple-mail-emlx

### email/attachment-tricky-filename.eml

- size: 643 bytes
- sha256: 5dfc33093885d6ea39ab2ca3fcd4abe70acb1c0433515258e44a66618b4c66a0
- what it is: An attachment whose filename uses RFC 2231 continuation encoding, contains a double extension and non-ASCII characters.
- expected: Filename sanitising on save. The name decodes to a double-extension file, which is exactly the pattern used to disguise executables. Also catches parsers that only understand the simple filename="..." form.
- page: https://hexaqa.com/file/email/attachment-tricky-filename-eml

### email/dkim-spf-headers.eml

- size: 1007 bytes
- sha256: ddc10028aad8088ea9d05c20e5edb33b9abf85da602a5d0c47371de0c277492c
- what it is: A message with a realistic Received chain plus Authentication-Results, DKIM-Signature and ARC headers.
- expected: Header-chain parsing and authentication display. Useful for testing code that surfaces SPF/DKIM/DMARC results, and for checking that a long Received chain is folded and read correctly.
- page: https://hexaqa.com/file/email/dkim-spf-headers-eml

### email/empty-body.eml

- size: 273 bytes
- sha256: 08a9c0d43008deae3ba10bd3bcf1eccfd8ad0bb0fd6c7df9696cc11b24f77ef3
- what it is: Valid headers followed by a completely empty body.
- expected: Readers that assume every message has content. A subject-only message is legitimate and common for calendar and notification mail.
- page: https://hexaqa.com/file/email/empty-body-eml

### email/forwarded-nested.eml

- size: 864 bytes
- sha256: 5abfbe80bb797acc0730b31f7ae1d820e91760d96d0a340e0347c181095995fc
- what it is: A forwarded message: a complete RFC 5322 message embedded as a message/rfc822 part inside another.
- expected: Recursive parsing. Catches extractors that treat the nested message as opaque text, and anything that does not recurse into message/rfc822 when scanning attachments.
- page: https://hexaqa.com/file/email/forwarded-nested-eml

### email/html-multipart.eml

- size: 593 bytes
- sha256: f0092b2f4414211ce1f3d5813729cc7ed0646f9f0fd4df5fd1de1e5ffd193a07
- what it is: multipart/alternative carrying both a text/plain and a text/html version of the same message.
- expected: Clients that pick the wrong alternative, or render the HTML part as literal text. Also catches parsers that stop at the first part.
- page: https://hexaqa.com/file/email/html-multipart-eml

### email/inline-image-cid.eml

- size: 774 bytes
- sha256: 3493781785165968715bd68abbd2d8a771ca8b49ee37ed73062bfa5a0bcf1f8a
- what it is: multipart/related where the HTML body references an inline image through a cid: URL.
- expected: Inline-image rendering. Catches clients that show the image as a separate attachment instead of inline, and HTML sanitisers that strip cid: references.
- page: https://hexaqa.com/file/email/inline-image-cid-eml

### email/long-folded-headers.eml

- size: 1033 bytes
- sha256: f59190b8aa44837cefff19dd8dc1e2b1eb45ac4f4b9b7e0af44bb571238b9f62
- what it is: Headers folded across many continuation lines, including a To: field with 25 recipients and a 300-character subject.
- expected: Header unfolding. Catches parsers that read one physical line per header, truncate at 78 characters, or lose recipients after the first fold.
- page: https://hexaqa.com/file/email/long-folded-headers-eml

### email/mailbox.mbox

- size: 1090 bytes
- sha256: 85ff4064c9efec3a74d56ef8d3abc2d064f32dd9402bde713e1ff70a216f54da
- what it is: An mbox archive of three messages, the format Gmail Takeout, Thunderbird and Apple Mail all export. Includes a body line beginning with "From " that has been escaped to ">From ".
- expected: mbox splitting. A parser that splits on every line starting with "From " will corrupt the third message; one that never unescapes ">From " will silently alter the body text.
- page: https://hexaqa.com/file/email/mailbox-mbox

### email/missing-required-headers.eml

- size: 103 bytes
- sha256: 3a617a25fbe83b53870bbd113f6ca0adc16e8b9e30d8be066b0354be1df25576
- what it is: A message with no Date and no Message-ID, and a body separated by a bare LF instead of CRLF.
- expected: Parsers that assume Date and Message-ID always exist, and ones that only split the header block on CRLFCRLF. Both are extremely common assumptions.
- page: https://hexaqa.com/file/email/missing-required-headers-eml

### email/outlook-message.msg

- size: 6656 bytes
- sha256: 4f95345c93341a36641fa1a849cb8503436e2f3b8143db8fab814938f6356cb8
- what it is: A genuine Outlook .msg: MAPI properties stored inside an OLE2 compound file, with a recipient sub-storage and the original transport headers preserved.
- expected: Outlook-specific handling. A .msg is a property bag, not a mail format, so no RFC 5322 parser can read it. Opens in Outlook and parses in extract_msg. Also a second OLE2 fixture, sharing its container with legacy .doc and .xls.
- page: https://hexaqa.com/file/email/outlook-message-msg

### email/plain-text.eml

- size: 337 bytes
- sha256: 761804bd96c81708c2e692bcaac173aac84182ffbc078b9dd6e891f3b63fe30a
- what it is: A minimal, fully valid RFC 5322 message: text/plain, UTF-8, CRLF line endings and all required headers.
- expected: Baseline for any .eml parser. Confirms header parsing, CRLF handling and that the body is separated by exactly one blank line.
- page: https://hexaqa.com/file/email/plain-text-eml

### email/quoted-printable.eml

- size: 535 bytes
- sha256: 74a8ec24d3d75585cd8eb718b6fa01b4cd1e5493b20b53fd9c04b417bd15ce28
- what it is: A quoted-printable body with accented characters, soft line breaks and an = sign at a wrap boundary.
- expected: Quoted-printable decoding. Catches decoders that mishandle soft line breaks (a trailing =) or fail to unescape =XX sequences.
- page: https://hexaqa.com/file/email/quoted-printable-eml

### email/spoofed-display-name.eml

- size: 410 bytes
- sha256: 6146a3fbb9e0c1c2effc36c6bc8396a1faddc2a87b36aaa536d350049c706762
- what it is: A display name that reads as a trusted address while the real envelope address is something else entirely.
- expected: Phishing display. Any client that shows only the display name presents this as coming from support@yourbank.example, when the actual address is attacker@evil.example.test. The single most common real-world phishing pattern.
- page: https://hexaqa.com/file/email/spoofed-display-name-eml

### email/threaded-reply.eml

- size: 551 bytes
- sha256: 93622a38599065bf45895c90078bdd1bb739898428d6c04737a0b06dd2b73863
- what it is: A reply carrying In-Reply-To and a References chain four messages deep.
- expected: Conversation threading. Clients that thread on subject alone will group this wrongly; ones that ignore References will orphan it.
- page: https://hexaqa.com/file/email/threaded-reply-eml

### email/unicode-headers.eml

- size: 427 bytes
- sha256: b1fdce2f073aca773af37f6e5cfdac7e9c654199d488ed6ce264f0505a943ef7
- what it is: Subject and display name encoded as RFC 2047 encoded-words (=?UTF-8?B?...?=) carrying CJK, Arabic and emoji.
- expected: Header decoding. A client that prints the raw =?UTF-8?B?...?= instead of the decoded text, or mangles the display name in a reply.
- page: https://hexaqa.com/file/email/unicode-headers-eml

### email/web-archive.mht

- size: 689 bytes
- sha256: a8dd4b87835bd6d9f23ed72b6cee8197e45c2a465e1c452cc8a03f0238c52182
- what it is: A MIME HTML archive: an HTML page and its image bundled into one multipart/related file, the format Outlook and Internet Explorer call a Web Archive.
- expected: MHTML handling. Same MIME container as email, which is why mail parsers often accept it and why it is a recurring vector for smuggling HTML past filters that only inspect the outer content type.
- page: https://hexaqa.com/file/email/web-archive-mht

### email/winmail-tnef.eml

- size: 695 bytes
- sha256: a788036cd4a5f4d46f0a658e914bc67e824c578b8527e8913df4f37a4caf4edb
- what it is: A message carrying an application/ms-tnef part named winmail.dat, which is how Outlook wraps rich formatting and attachments when it uses TNEF.
- expected: The classic "why did I receive winmail.dat" bug. Catches clients that surface the TNEF blob as an unreadable attachment instead of decoding the attachments inside it.
- page: https://hexaqa.com/file/email/winmail-tnef-eml

### email/with-attachment.eml

- size: 693 bytes
- sha256: ca97de3ad84e6e15180a50d27b2a9195d4a77ea10f6fce7e3ae5ff6f47c3e3bf
- what it is: multipart/mixed with a base64-encoded PNG attachment and a Content-Disposition filename.
- expected: Attachment extraction: base64 decoding, filename parsing, and handlers that assume every part is text.
- page: https://hexaqa.com/file/email/with-attachment-eml

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
