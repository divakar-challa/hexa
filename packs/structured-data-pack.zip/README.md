# Structured Data Pack

Valid baselines in five formats plus the ones that break parsers: quoted commas and embedded newlines in CSV, a BOM on the header row, formula injection, JSON with trailing commas and integers past 2^53, 100,000 levels of nesting, XML entity expansion and external-entity disclosure, and the YAML Norway problem.

14 files, 857 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Import pipelines and API request handling. Every valid file should round-trip exactly; every hostile one should be rejected with a specific error rather than accepted, hung on, or crashed.

## Files

### csv/valid-simple.csv

- size: 4368 bytes
- sha256: dfb9d357c93e725493c48f9c0e8cca6b92bcaf0826bcdb493e4ffe3e7bcc1f91
- what it is: Header row plus 100 rows of clean, unquoted ASCII data.
- expected: Parses. The control.
- page: https://hexaqa.com/file/structured-data/valid-simple-csv

### csv/quoting-nightmare.csv

- size: 407 bytes
- sha256: 557f8d813aa8cec4212f6bcb3e6a11cfdeadc48fab3d825f2e9a7fb26bd36d5e
- what it is: Every RFC 4180 quoting edge case in one file: embedded commas, embedded newlines inside quoted fields, escaped double quotes, leading and trailing whitespace, and empty fields.
- expected: Quoted fields containing commas and newlines kept intact.
- page: https://hexaqa.com/file/structured-data/quoting-nightmare-csv

### csv/bom-and-semicolons.csv

- size: 124 bytes
- sha256: f011c1f7fd1b20aa993782865d5884ca6aa23089fabe5dc560b47c041bdf080a
- what it is: UTF-8 BOM, semicolon delimiters and comma decimal separators - the format Excel produces in most European locales.
- expected: BOM stripped, semicolon delimiter detected.
- page: https://hexaqa.com/file/structured-data/bom-and-semicolons-csv

### csv/ragged-rows.csv

- size: 123 bytes
- sha256: 2292b423c8910544ee2df0a720e17cfaebb15f10270c0dd64e39bfc411635cb4
- what it is: Rows with too few and too many columns relative to the header.
- expected: Rows with the wrong column count rejected or padded deliberately.
- page: https://hexaqa.com/file/structured-data/ragged-rows-csv

### csv/formula-injection.csv

- size: 357 bytes
- sha256: c591c3c65f09f7ce69b6b47558650baf9ad511d14df5c95e0fdd9977bcbf0d0f
- what it is: Cells beginning with =, +, -, @ and tab, which spreadsheet applications interpret as formulas. The payloads are non-destructive: they reference HYPERLINK and a harmless calculation.
- expected: Leading = + - @ escaped on export to a spreadsheet.
- page: https://hexaqa.com/file/structured-data/formula-injection-csv

### json/valid-small.json

- size: 382 bytes
- sha256: 9f03d9acaf3a05e29965226b4f1b874463c5ebfbd00a70c95a2de3a5b6785a5f
- what it is: Well-formed JSON object with nested arrays, nulls, booleans, unicode and escaped characters.
- expected: Every scalar type, nesting, Unicode and escapes. Parses.
- page: https://hexaqa.com/file/structured-data/valid-small-json

### json/malformed-trailing-comma.json

- size: 24 bytes
- sha256: d66c56297d3e2d3c7854ff366bccce90d007c64d890f21388bf0fc266a4219b9
- what it is: JSON with a trailing comma before the closing brace - invalid per RFC 8259.
- expected: Rejected. It is not valid JSON, whatever your parser thinks.
- page: https://hexaqa.com/file/structured-data/malformed-trailing-comma-json

### json/precision-loss.json

- size: 319 bytes
- sha256: 7075086fd6d6809ccd379203d3d4f803c22d4c44593b109f0032b1a8b9ba2e08
- what it is: Integers and decimals that exceed IEEE-754 double precision: 64-bit IDs, high-precision decimals, and values at MAX_SAFE_INTEGER boundaries.
- expected: Integers above 2^53 preserved, or the loss handled knowingly.
- page: https://hexaqa.com/file/structured-data/precision-loss-json

### json/deeply-nested-100000.json

- size: 200002 bytes
- sha256: 8d7bd09c0573c0c4d854b55795e2c3f1a781c2d4f2901de332a5cb8bab350e42
- what it is: A single value wrapped in 100,000 levels of nested arrays. Only ~200 KB on disk.
- expected: Rejected at a depth limit, not by a stack overflow.
- page: https://hexaqa.com/file/structured-data/deeply-nested-100000-json

### json/ndjson-10000-lines.ndjson

- size: 669861 bytes
- sha256: baf8acced4ee3f7087b0a5261b9f5dadb6908c46062b71711ee06a155e4a0f54
- what it is: Newline-delimited JSON, 10,000 records, one object per line.
- expected: Streamed line by line rather than parsed whole.
- page: https://hexaqa.com/file/structured-data/ndjson-10000-lines-ndjson

### xml/valid.xml

- size: 395 bytes
- sha256: 83894bdebdcc14d2a95a4144e89839b39b66b775dc53fde2a886a3f78549f490
- what it is: Well-formed XML with namespaces, attributes, CDATA and a comment.
- expected: Parses. The control.
- page: https://hexaqa.com/file/structured-data/valid-xml

### xml/billion-laughs.xml

- size: 794 bytes
- sha256: 9ca01fc0e877f248ff50f66de22330cbfb71785e34f26656cf68a0aac21f642c
- what it is: Classic entity-expansion bomb: nine levels of entities each referencing the previous ten times. Under 1 KB on disk, expands to ~1 GB of text if entity expansion is unbounded.
- expected: Rejected: entity expansion disabled.
- page: https://hexaqa.com/file/structured-data/billion-laughs-xml

### xml/xxe-file-disclosure.xml

- size: 141 bytes
- sha256: 3b24847c3f0f1c1e34b3d8b2bee9d2229da9613a35b7163bb4842ffcaf4aae83
- what it is: XML declaring an external entity that reads a local file. Targets /etc/hostname - deliberately innocuous rather than /etc/passwd.
- expected: Parsed with external entity resolution off.
- page: https://hexaqa.com/file/structured-data/xxe-file-disclosure-xml

### yaml/norway-problem.yaml

- size: 161 bytes
- sha256: 17ba9fa29d8d1969a11d0f7ca1bce8c25a8421d2b0397b5ecc68616fe033332b
- what it is: YAML 1.1 implicit-typing traps: unquoted NO becomes false, unquoted YES becomes true, version strings become floats, and leading-zero values parse as octal.
- expected: The country code NO stays a string and does not become false.
- page: https://hexaqa.com/file/structured-data/norway-problem-yaml

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
