# Filename Compatibility Pack

All 26 filename edge cases in one archive: reserved Windows device names, trailing dots and spaces, path separators, quotes, Unicode in several scripts, both normalization forms, a right-to-left override, a 200-character name and one with no extension at all.

26 files, 4 KB uncompressed.

Every file is generated from source, so none of it carries third-party copyright and all of it is free
to redistribute. Digests below are SHA-256 and match the standalone downloads on hexaqa.com byte for byte.

## What to expect

Anything that moves files between operating systems: sync clients, backup tools, archive extractors, upload forms and object-storage adapters. Extract this archive on Windows, macOS and Linux and compare what survives. The differences are the bugs.

Your extractor will probably not give you all 26 files back, and that is the point of the pack.
Known behaviour worth expecting rather than reporting as a bug in the archive:

- `backslash\name.txt` contains a literal backslash. The ZIP spec uses forward slash as the only
  path separator, so this is a legal character in a name, but many extractors (including Python's
  zipfile) treat it as a separator and hand you a directory called `backslash` instead. Both
  behaviours exist in the wild; neither is a corruption of this archive.
- Windows refuses `CON.txt`, `NUL.txt`, `question?name.txt`, `double"quote.txt` and
  `backslash\name.txt` outright, and silently strips the dot from `trailing-dot.txt.`.
- macOS stores filenames decomposed, so `nfc-café.txt` and `nfd-café.txt` may collide into one file
  on an HFS+ volume and stay separate on APFS.
- Case-insensitive file systems collapse `UPPERCASE.TXT` against any lowercase twin.

Extract on each platform you support and diff the results against manifest.json.

## Files

### filename/.hidden-leading-dot

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Leading dot, no extension - hidden on POSIX.
- expected: Directory listings that filter dotfiles, and extension parsers that see an empty basename.
- page: https://hexaqa.com/file/filename-edge-cases/hidden-leading-dot

### filename/🦊-emoji-name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Emoji (4-byte UTF-8, outside the BMP) in the filename.
- expected: Systems that store names as UTF-16 and count length in code units, or databases on utf8 rather than utf8mb4 - MySQL will reject or truncate this.
- page: https://hexaqa.com/file/filename-edge-cases/emoji-name-txt

### filename/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A 204-character filename.
- expected: Filesystem limits (255 bytes on ext4, and 255 UTF-16 units on NTFS), plus database columns sized at VARCHAR(100) or VARCHAR(255) that truncate on insert.
- page: https://hexaqa.com/file/filename-edge-cases/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-txt

### filename/ampersand&name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: An ampersand in the filename.
- expected: Query-string construction and unescaped HTML rendering of the name.
- page: https://hexaqa.com/file/filename-edge-cases/ampersand-name-txt

### filename/archive.tar.gz

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A legitimate compound extension.
- expected: The control case for the double-extension test: this one must be accepted.
- page: https://hexaqa.com/file/filename-edge-cases/archive-tar-gz

### filename/backslash\name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A backslash in the filename.
- expected: Cross-platform path handling - Windows treats this as a directory separator, POSIX does not.
- page: https://hexaqa.com/file/filename-edge-cases/backslash-name-txt

### filename/CON.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A Windows reserved device name.
- expected: Windows cannot create files named CON, PRN, AUX, NUL, COM1-9 or LPT1-9, even with an extension. Extraction and download on Windows will fail unless the name is sanitised.
- page: https://hexaqa.com/file/filename-edge-cases/con-txt

### filename/dots.in.the.name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Multiple dots.
- expected: Extension detection that splits on the first dot rather than the last.
- page: https://hexaqa.com/file/filename-edge-cases/dots-in-the-name-txt

### filename/double"quote.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: An ASCII double quote in the filename.
- expected: Content-Disposition header construction - an unescaped quote terminates the filename parameter early and can inject further header directives.
- page: https://hexaqa.com/file/filename-edge-cases/double-quote-txt

### filename/hash#name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A hash character in the filename.
- expected: URL handling - everything after # becomes a fragment and never reaches the server.
- page: https://hexaqa.com/file/filename-edge-cases/hash-name-txt

### filename/invoice‮gnp.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Contains a right-to-left override (U+202E) so it renders as "invoicetxt.png".
- expected: A spoofing vector: the displayed name misrepresents the real extension. Filename display should strip or escape bidi control characters.
- page: https://hexaqa.com/file/filename-edge-cases/invoice-gnp-txt

### filename/nfc-café.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Precomposed Unicode (NFC): é is a single code point U+00E9.
- expected: Pair with the NFD file. They look identical but differ byte-for-byte, so dedupe and lookup by name must normalise first. macOS stores NFD, Linux stores what it is given.
- page: https://hexaqa.com/file/filename-edge-cases/nfc-caf-txt

### filename/nfd-café.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Decomposed Unicode (NFD): é is e + U+0301 combining acute.
- expected: The other half of the normalisation pair.
- page: https://hexaqa.com/file/filename-edge-cases/nfd-caf-txt

### filename/no-extension-at-all

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: No extension at all.
- expected: Type detection that depends on extension rather than content sniffing.
- page: https://hexaqa.com/file/filename-edge-cases/no-extension-at-all

### filename/NUL.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Another Windows reserved device name.
- expected: Same as CON.txt - writes silently go to the null device on some Windows APIs.
- page: https://hexaqa.com/file/filename-edge-cases/nul-txt

### filename/percent%20encoded.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A literal "%20" sequence in the filename.
- expected: Double-decoding bugs, where the stored name becomes "percent encoded.txt" after one decode too many.
- page: https://hexaqa.com/file/filename-edge-cases/percent-20encoded-txt

### filename/plus+name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A plus sign in the filename.
- expected: Form-encoded decoding that turns + into a space.
- page: https://hexaqa.com/file/filename-edge-cases/plus-name-txt

### filename/question?name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A question mark in the filename.
- expected: URL handling - everything after ? becomes a query string.
- page: https://hexaqa.com/file/filename-edge-cases/question-name-txt

### filename/report.pdf.exe

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Double extension where the real extension is last.
- expected: Blocklists that check only the first extension, and UI that truncates the displayed name and hides the dangerous suffix.
- page: https://hexaqa.com/file/filename-edge-cases/report-pdf-exe

### filename/semicolon;name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A semicolon in the filename.
- expected: Content-Disposition parsing, where semicolon separates parameters.
- page: https://hexaqa.com/file/filename-edge-cases/semicolon-name-txt

### filename/single'quote.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: An ASCII single quote in the filename.
- expected: SQL string building and unquoted shell arguments.
- page: https://hexaqa.com/file/filename-edge-cases/single-quote-txt

### filename/spaces in name.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Spaces in the filename.
- expected: URL construction that forgets to percent-encode, and shell commands built by string concatenation.
- page: https://hexaqa.com/file/filename-edge-cases/spaces-in-name-txt

### filename/trailing-dot.txt.

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: A trailing dot after the extension.
- expected: Windows silently strips trailing dots, so this file can collide with trailing-dot.txt on save.
- page: https://hexaqa.com/file/filename-edge-cases/trailing-dot-txt

### filename/UPPERCASE.TXT

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: All-caps name and extension.
- expected: Case-sensitivity mismatches between a case-insensitive dev machine (macOS, Windows) and a case-sensitive production filesystem (Linux) or object store (S3/R2 are case-sensitive).
- page: https://hexaqa.com/file/filename-edge-cases/uppercase-txt

### filename/файл-кириллица.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Cyrillic characters in the filename.
- expected: As above, with a different script.
- page: https://hexaqa.com/file/filename-edge-cases/txt

### filename/日本語ファイル名.txt

- size: 142 bytes
- sha256: fc489d07339b8e178a978a486b5527072e41f6454289d4d53fb2a3be7e4953dd
- what it is: Japanese characters in the filename.
- expected: Non-ASCII names require RFC 5987 filename* encoding in Content-Disposition; the plain filename parameter cannot carry them.
- page: https://hexaqa.com/file/filename-edge-cases/txt

## Licence and safety

Free to use, redistribute and modify, with or without attribution. Nothing in this pack is malware.
Some files are deliberately malformed and a few are designed to be mishandled by careless software,
so extract and run them in a disposable environment rather than on a machine you care about.

https://hexaqa.com/test-packs
